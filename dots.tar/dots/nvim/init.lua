vim.g.have_nerd_font = true
vim.opt.termguicolors = true
vim.opt.clipboard = "unnamedplus"
vim.opt.mouse = ""
vim.opt.smartindent = true
vim.opt.cursorline = true
vim.opt.wrap = false
vim.opt.cmdheight = 0 -- Hide command line unless needed.
vim.opt.sidescrolloff = 8
vim.g.mapleader = " "

local map = vim.keymap.set
map('n', '<leader>w', '<Cmd>update<CR>')

vim.cmd("colorscheme tokyonight-night")
