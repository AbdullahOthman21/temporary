require("tokyonight").load({
  style = vim.o.background == "light" and "day" or nil,
})
